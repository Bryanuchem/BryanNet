BOT_TOKEN = "8945857318:AAGpO4IIpnPe3fdh1jWjRJHAdoAgwnWhHuE"

API_BASE_URL = (
    "http://127.0.0.1:8000/api/v1"
)