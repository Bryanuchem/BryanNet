import requests

from telegram import (
    Update
)

from telegram.ext import (
    ContextTypes
)

from bot.config import API_BASE_URL
from bot.session import render_session


async def onboarding_handler(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE
):

    telegram_user_id = update.effective_user.id

    # Ask the API what stage the customer is in

    session_response = requests.get(
        f"{API_BASE_URL}/session/telegram/{telegram_user_id}"
    )

    if session_response.status_code != 200:
        return

    session = session_response.json()

    next_action = session["next_action"]

    # Customer is already fully onboarded.
    # Let the normal keyboard handler process the message.

    if next_action == "SHOW_MAIN_MENU":
        return

    # Save customer's full name

    if next_action == "ENTER_NAME":

        if not update.message.text:
            return

        response = requests.patch(
            f"{API_BASE_URL}/customers/onboarding/name",
            json={
                "telegram_user_id": telegram_user_id,
                "full_name": update.message.text
            }
        )

        if response.status_code != 200:

            await update.message.reply_text(
                "Unable to save your name."
            )

            return
        
    # Save customer's phone number

    elif next_action == "ENTER_PHONE":

        if update.message.contact is None:

            await update.message.reply_text(
                "Please tap '📱 Share Phone Number'."
            )

            return

        response = requests.patch(
            f"{API_BASE_URL}/customers/onboarding/phone",
            json={
                "telegram_user_id": telegram_user_id,
                "phone_number": update.message.contact.phone_number
            }
        )

        if response.status_code != 200:

            await update.message.reply_text(
                "Unable to save your phone number."
            )

            return

    # Refresh the screen using the latest session

    if next_action == "ENTER_PHONE":

        session = requests.get(
            f"{API_BASE_URL}/session/telegram/{telegram_user_id}?first_login=true"
        ).json()

        await render_session(
            update.message,
            telegram_user_id,
            session=session
        )

    else:

        await render_session(
            update.message,
            telegram_user_id
        )